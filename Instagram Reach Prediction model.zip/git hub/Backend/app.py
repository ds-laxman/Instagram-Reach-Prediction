from flask import Flask, render_template, request
import pandas as pd
import plotly.graph_objects as go
import statsmodels.api as sm
import os
import uuid

app = Flask(__name__)
UPLOAD_FOLDER = 'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@app.route('/', methods=['GET', 'POST'])
def index():
    plot_html = ""
    error_msg = ""
    summary = {}
    if request.method == 'POST':
        file = request.files['file']
        if file:
            try:
                filepath = os.path.join(app.config['UPLOAD_FOLDER'], f"{uuid.uuid4()}_{file.filename}")
                file.save(filepath)

                # Handle encoding issues
                data = pd.read_csv(filepath, encoding='latin1')

                # Check required columns
                if 'Date' not in data.columns or 'Instagram reach' not in data.columns:
                    raise ValueError("CSV must contain 'Date' and 'Instagram reach' columns.")

                # Prepare dataset
                data['Date'] = pd.to_datetime(data['Date'])
                data.set_index('Date', inplace=True)

                # Summary stats
                summary = {
                    "Start Date": data.index.min().strftime("%Y-%m-%d"),
                    "End Date": data.index.max().strftime("%Y-%m-%d"),
                    "Max Reach": int(data["Instagram reach"].max()),
                    "Min Reach": int(data["Instagram reach"].min())
                }

                # SARIMA Forecasting
                p, d, q = 8, 1, 2
                model = sm.tsa.statespace.SARIMAX(data["Instagram reach"],
                                                  order=(p, d, q),
                                                  seasonal_order=(p, d, q, 12))
                model = model.fit()
                predictions = model.predict(len(data), len(data) + 100)

                # Plotly chart
                trace_train = go.Scatter(x=data.index,
                                         y=data["Instagram reach"],
                                         mode="lines",
                                         name="Training Data",
                                         line=dict(color='blue'))

                trace_pred = go.Scatter(x=predictions.index,
                                        y=predictions.rolling(window=5).mean(),  # Smooth forecast
                                        mode="lines",
                                        name="Predictions",
                                        line=dict(color='red', dash='dash'))

                layout = go.Layout(
                    title="Instagram Reach Time Series and Predictions",
                    xaxis_title="Date",
                    yaxis_title="Instagram Reach",
                    xaxis=dict(tickformat="%b-%Y", tickangle=45, showgrid=True, gridcolor='lightgrey'),
                    yaxis=dict(showgrid=True, gridcolor='lightgrey'),
                    plot_bgcolor='white',
                    paper_bgcolor='white'
                )

                fig = go.Figure(data=[trace_train, trace_pred], layout=layout)
                plot_html = fig.to_html(full_html=False)

            except Exception as e:
                error_msg = f"<p style='color:red;'>Error: {str(e)}</p>"

    return render_template('index.html', plot_html=plot_html + error_msg, summary=summary)

if __name__ == '__main__':
    app.run(debug=True)
